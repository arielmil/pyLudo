# pyLudo
trabalho de python

#Todos os casos de testes se encontram no arquivo .py Testa_Tudo
#Os arquivos de testes como Testa_Peao, Testa_Dado, etc, se referem aos testes relativos aqueles módulos.
#Atenção ao caso de teste do módulo Player